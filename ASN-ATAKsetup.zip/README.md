Setup file for http://airsoftnorge.com/tak servers

Download the as zip, open ATAK, Import Manager, select from SD card, navigate to the file and import.
This will give you the standard access and maps for airsoftnorge.com TAK.

Download link: https://github.com/airsoftnorge/ataksetup/archive/refs/heads/main.zip

https://airsoftnorge.com/atak-setup/
